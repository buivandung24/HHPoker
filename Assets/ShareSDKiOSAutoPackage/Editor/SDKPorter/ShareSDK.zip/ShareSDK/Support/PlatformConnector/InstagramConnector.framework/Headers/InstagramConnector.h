//
//  InstagramConnector.h
//  ShareSDKConnector
//
//  Created by 冯鸿杰 on 16/9/28.
//  Copyright © 2016年 mob. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  Instagram连接器
 */
@interface InstagramConnector : NSObject

@end
